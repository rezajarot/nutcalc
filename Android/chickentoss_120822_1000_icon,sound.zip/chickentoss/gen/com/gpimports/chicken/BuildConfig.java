/** Automatically generated file. DO NOT MODIFY */
package com.gpimports.chicken;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}