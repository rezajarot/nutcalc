//
//  PaperTossViewController.m
//  PaperToss
//
//  Created by Developer on 2/19/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "ChickenTossViewController.h"

@implementation ChickenTossViewController


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	m_fSound = TRUE;
	
	NSString * szMenuSound = [[NSBundle mainBundle] pathForResource:@"BounceIn" ofType:@"wav"];
	NSURL *urlMenuSound = [NSURL fileURLWithPath:szMenuSound];
	AudioServicesCreateSystemSoundID((CFURLRef)urlMenuSound, &m_BouncelnSound);
	
	szMenuSound = [[NSBundle mainBundle] pathForResource:@"Crumple" ofType:@"wav"];
	urlMenuSound = [NSURL fileURLWithPath:szMenuSound];
	AudioServicesCreateSystemSoundID((CFURLRef)urlMenuSound, &m_CrumpleSound);
	
	szMenuSound = [[NSBundle mainBundle] pathForResource:@"In" ofType:@"wav"];
	urlMenuSound = [NSURL fileURLWithPath:szMenuSound];
	AudioServicesCreateSystemSoundID((CFURLRef)urlMenuSound, &m_InSound);
	
	szMenuSound = [[NSBundle mainBundle] pathForResource:@"Out" ofType:@"wav"];
	urlMenuSound = [NSURL fileURLWithPath:szMenuSound];
	AudioServicesCreateSystemSoundID((CFURLRef)urlMenuSound, &m_OutSound);
	
	szMenuSound = [[NSBundle mainBundle] pathForResource:@"RimIn" ofType:@"wav"];
	urlMenuSound = [NSURL fileURLWithPath:szMenuSound];
	AudioServicesCreateSystemSoundID((CFURLRef)urlMenuSound, &m_RimInSound);
	
	szMenuSound = [[NSBundle mainBundle] pathForResource:@"RimOut" ofType:@"wav"];
	urlMenuSound = [NSURL fileURLWithPath:szMenuSound];
	AudioServicesCreateSystemSoundID((CFURLRef)urlMenuSound, &m_RimOutSound);

	easyScore = 0;
	mediumScore = 0;
	hardScore = 0;
	airportScore = 0;
	basementScore = 0;
	restroomScore = 0;
	pubScore = 0 ;
	streetScore = 0;
	
	m_TrackMaker = new TrackMaker;
	
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
	{
		m_TrackMaker->SetMachine(MACHINE_IPHONE);		
	}
	else
	{
		m_TrackMaker->SetMachine(MACHINE_IPAD);
	}

    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;	
}

- (void)dealloc {
	AudioServicesDisposeSystemSoundID(m_BouncelnSound);
	AudioServicesDisposeSystemSoundID(m_CrumpleSound);
	AudioServicesDisposeSystemSoundID(m_InSound);
	AudioServicesDisposeSystemSoundID(m_OutSound);
	AudioServicesDisposeSystemSoundID(m_RimInSound);
	AudioServicesDisposeSystemSoundID(m_RimOutSound);
	
	if (m_TrackMaker)
		delete m_TrackMaker;
	
    [super dealloc];
}


#pragma mark CALLBACK

- (void)checkMainMenu:(UIViewController *)controller gainScore:(NSInteger)score
{
	if (controller == easyController)
		easyScore = score;
	if (controller == mediumController)
		mediumScore = score;
	if (controller == hardController)
		hardScore = score;
	/*if (controller == airportController)
		airportScore = score;
	if (controller == basementController)
		basementScore = score;
	if (controller == restroomController)
		restroomScore = score;
	if (controller == pubController)
		pubScore = score;
	if (controller == streetController)
		streetScore = score;*/
	
	[self dismissModalViewControllerAnimated:YES];
}

-(void) checkplayBounceInSound{
	[self playBounceInSound];
}

-(void) checkplayCrumpleSound{
	[self playCrumpleSound];
}

-(void) checkplayInSound{
	[self playInSound];
}

-(void) checkplayOutSound{
	[self playOutSound];
}

-(void) checkplayRimInSound{
	[self playRimInSound];
}

-(void) checkplayRimOutSound{
	[self playRimOutSound];
}


#pragma mark IBAction

-(IBAction)onEasy:(id)sender
{
	easyController.delegate = self;
	
	[easyController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[easyController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:easyController animated:YES];
	
	[easyController initGame];
}

-(IBAction)onMedium:(id)sender
{
	mediumController.delegate = self;
	
	[mediumController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[mediumController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:mediumController animated:YES];
	
	[mediumController initGame];
}


-(IBAction)onHard:(id)sender
{
	hardController.delegate = self;
	
	[hardController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[hardController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:hardController animated:YES];
	
	[hardController initGame];
}


-(IBAction)onQuit:(id)sender
{
	exit(0);
}


/*-(IBAction)onAirport:(id)sender
{
	airportController.delegate = self;
	
	[airportController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[airportController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:airportController animated:YES];
	
	[airportController initGame];
}


-(IBAction)onBasement:(id)sender
{
	basementController.delegate = self;
	
	[basementController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[basementController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:basementController animated:YES];
	
	[basementController initGame];
}


-(IBAction)onRestroom:(id)sender
{
	restroomController.delegate = self;
	
	[restroomController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[restroomController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:restroomController animated:YES];
	
	[restroomController initGame];
}


-(IBAction)onPub:(id)sender
{
	pubController.delegate = self;
	
	[pubController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[pubController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:pubController animated:YES];
	
	[pubController initGame];
}


-(IBAction)onStreet:(id)sender
{
	streetController.delegate = self;
	
	[streetController setSound:m_fSound otherTracker:m_TrackMaker];
	
	[streetController setModalTransitionStyle: UIModalTransitionStyleFlipHorizontal];
	[self presentModalViewController:streetController animated:YES];
	
	[streetController initGame];
}


-(IBAction)onRemoveAds:(id)sender
{
	UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Remove ads?" 
			message:nil delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
	
	[alert show];
	[alert release];
}

-(IBAction)onSelSBoard:(id)sender
{
	sboardViewController.delegate = self;
	[sboardViewController setScore:easyScore othermedium:mediumScore otherhard:hardScore otherairport:airportScore 
					 otherbasement:basementScore otherrestroom:restroomScore otherpub:pubScore otherstreet:streetScore];
	
	[self presentModalViewController:sboardViewController animated:YES];	
	[sboardViewController dispScore];
}

-(IBAction)onMoreGames:(id)sender
{
	moregameViewController.delegate = self;
	[self presentModalViewController:moregameViewController animated:YES];	
}*/

-(IBAction)onSoundOnOff:(id)sender
{
	m_fSound = m_fSound == TRUE ? FALSE : TRUE;
	
	if (m_fSound)
	{
		NSString *str = [NSString stringWithFormat: @"Sound: On"];	
		
		[btSound setTitle:str forState:UIControlStateNormal];
	}
	else
	{
		NSString *str = [NSString stringWithFormat: @"Sound: Off"];	
		
		[btSound setTitle:str forState:UIControlStateNormal];
	}
}

#pragma mark Sound

-(void)playBounceInSound{
	AudioServicesPlaySystemSound(m_BouncelnSound);
}

-(void)playCrumpleSound{
	AudioServicesPlaySystemSound(m_CrumpleSound);
}

-(void)playInSound{
	AudioServicesPlaySystemSound(m_InSound);
}

-(void)playOutSound{
	AudioServicesPlaySystemSound(m_OutSound);	
}

-(void)playRimInSound{
	AudioServicesPlaySystemSound(m_RimInSound);	
}

-(void)playRimOutSound{
	AudioServicesPlaySystemSound(m_RimOutSound);	
}

@end
