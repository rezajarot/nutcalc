package com.gpimports.chicken;

import java.io.IOException;

import org.anddev.andengine.audio.music.Music;
import org.anddev.andengine.audio.music.MusicFactory;
import org.anddev.andengine.audio.sound.Sound;
import org.anddev.andengine.audio.sound.SoundFactory;
import org.anddev.andengine.engine.Engine;
import org.anddev.andengine.engine.camera.Camera;
import org.anddev.andengine.engine.handler.timer.ITimerCallback;
import org.anddev.andengine.engine.handler.timer.TimerHandler;
import org.anddev.andengine.engine.options.EngineOptions;
import org.anddev.andengine.engine.options.EngineOptions.ScreenOrientation;
import org.anddev.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.scene.Scene.IOnAreaTouchListener;
import org.anddev.andengine.entity.scene.Scene.ITouchArea;
import org.anddev.andengine.entity.shape.modifier.MoveModifier;
import org.anddev.andengine.entity.shape.modifier.ScaleModifier;
import org.anddev.andengine.entity.sprite.Sprite;
import org.anddev.andengine.entity.sprite.TiledSprite;
import org.anddev.andengine.entity.text.ChangeableText;
import org.anddev.andengine.input.touch.TouchEvent;
import org.anddev.andengine.opengl.font.Font;
import org.anddev.andengine.opengl.font.StrokeFont;
import org.anddev.andengine.opengl.texture.Texture;
import org.anddev.andengine.opengl.texture.TextureOptions;
import org.anddev.andengine.opengl.texture.region.TextureRegion;
import org.anddev.andengine.opengl.texture.region.TextureRegionFactory;
import org.anddev.andengine.opengl.texture.region.TiledTextureRegion;

import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.DisplayMetrics;

public class MiddleScene extends BaseExample{

	private static int camera_width;
	private static int camera_height;
	private float scaled_width;
	private float scaled_height;
	
	private Camera mCamera;
	
	private Texture mMiddleBackgoundTexture;
	private Texture mArrowTexture;
	private Texture mScoreFontTexture;
	private Texture mPaperTexture;
	private Texture mFanRightTexture[];
	private Texture mFanLeftTexture[];
	private Texture mWindArrowTexture[];
	private Texture mFontTexture;
	private Texture mMenuTexture;
	private Texture mRecycleTexture;
	
	private TextureRegion mMiddleBackgroundRegion;
	private TextureRegion mArrowTextureRegion;
	private TiledTextureRegion mPaperTextureRegion;
	private TextureRegion mFanRightTextureRegion[];
	private TextureRegion mFanLeftTextureRegion[];
	private TextureRegion mWindArrowRegion[];
	private TextureRegion mMenuRegion;
	private TextureRegion mRecycleTextureRegion;
	
	private Font mFont;
	private ChangeableText mScoreText;
	private ChangeableText mBestText;

	private Sprite mMiddleBackgroundSprite;
	private Sprite mArrowSprite;
	private TiledSprite mPaperSprite;
	private Sprite mFanRightSprite[];
	private Sprite mFanLeftSprite[];
	private Sprite mWindArrowSprite[];
	private Sprite mMenuSprite;
	private Sprite mRecycleSprite;
	
	private Scene mScene;
	
	private PointF ptScore, ptBest;
	private PointF ptPaper;
	public static int mScore = 0;
	public static int mBest = 0;
	
	private TimerHandler handle, fanHandle;
	private int mFanPosition;
	private final int FAN_POSITION_LEFT = 0;
	private final int FAN_POSITION_RIGHT = 1;
	
	private float m_rFan_A;
	private int m_nFanIndex;
	private ChangeableText mSpeedText;
	private StrokeFont mAllowFont;
	
	private TrackMaker mTrackMaker;
	private float mAlpha = 0.0f;
	private boolean mMove = false;
	private boolean mGoal = false;
	private static boolean m_fSubmit = false;
	private int m_nFrameNum = 0;
	
	private int[] m_nCenterX, m_nCenterY, m_nBallIndex, nState;
	private float[] m_rScale;
	private float m_rInitPaperSize;
	private RectF mPaperInitRect;
	
	private float initWidth = 0.0f;
	private float initHeight = 0.0f;
	private Music mMiddleBackMusic = null;
	private Sound mSounds[];
	
	private boolean mTopPaper = false;
	
	
	public Engine onLoadEngine() {
		// TODO Auto-generated method stub
		getScaledCoordinate();
		this.mCamera = new Camera(0, 0, camera_width, camera_height);
		return new Engine(new EngineOptions(true, ScreenOrientation.PORTRAIT, new RatioResolutionPolicy(camera_width, camera_height), this.mCamera).setNeedsMusic(true).setNeedsSound(true));
	}

	
	public void onLoadResources() {
		// TODO Auto-generated method stub		
		mMiddleBackgoundTexture = new Texture(1024, 1024, TextureOptions.DEFAULT );
		mArrowTexture = new Texture(128, 128, TextureOptions.DEFAULT);
		mScoreFontTexture = new Texture(256, 256, TextureOptions.DEFAULT);
		mPaperTexture = new Texture(1024, 256, TextureOptions.DEFAULT);
		mMenuTexture = new Texture(256, 256, TextureOptions.DEFAULT );
		mRecycleTexture = new Texture(256, 256, TextureOptions.DEFAULT );
		
		mWindArrowTexture = new Texture[2];
		mWindArrowTexture[0] = new Texture(256, 256, TextureOptions.DEFAULT);
		mWindArrowTexture[1] = new Texture(256, 256, TextureOptions.DEFAULT);
		mFontTexture = new Texture(256, 256, TextureOptions.BILINEAR_PREMULTIPLYALPHA);
		
		mMiddleBackgroundRegion = TextureRegionFactory.createFromAsset(mMiddleBackgoundTexture, this, "gfx/background_lvl2.png", 0, 0);
		mArrowTextureRegion = TextureRegionFactory.createFromAsset(mArrowTexture, this, "gfx/arrow1.png", 0, 0);
		mPaperTextureRegion = TextureRegionFactory.createTiledFromAsset( mPaperTexture, this, "gfx/chicken.png", 0, 0, 8, 1 );
		mMenuRegion = TextureRegionFactory.createFromAsset(mMenuTexture, this, "gfx/menu.png", 0, 0);
		mRecycleTextureRegion = TextureRegionFactory.createFromAsset(mRecycleTexture, this, "gfx/bucket_lvl2.png", 0, 0);
		m_rInitPaperSize = mPaperTextureRegion.getWidth() * scaled_width;

		mFont = new Font(this.mScoreFontTexture, Typeface.create(Typeface.DEFAULT, Typeface.BOLD), 20, true, Color.WHITE);
		mAllowFont = new StrokeFont(this.mFontTexture, Typeface.create(Typeface.DEFAULT, Typeface.NORMAL), Global.FONT_SIZE_ARROW, true, Color.BLACK, 1, Color.WHITE);

		//loadFanTexture();
		loadSound();
		
		mWindArrowRegion = new TextureRegion[2];
		mWindArrowRegion[0] = TextureRegionFactory.createFromAsset(mWindArrowTexture[0], this, "gfx/breeze_light_R.png", 0, 0);
		mWindArrowRegion[1] = TextureRegionFactory.createFromAsset(mWindArrowTexture[1], this, "gfx/breeze_light_L.png", 0, 0);
		
		mWindArrowSprite = new Sprite[2];
		
		mEngine.getTextureManager().loadTextures(mMiddleBackgoundTexture, mArrowTexture,  
				mScoreFontTexture, mPaperTexture, mWindArrowTexture[0], mWindArrowTexture[1], mFontTexture,
				/*mFanRightTexture[0], mFanRightTexture[1], mFanLeftTexture[0], mFanLeftTexture[1],
				mFanLeftTexture[0], mFanLeftTexture[1],*/ mMenuTexture, mRecycleTexture);
		
		mEngine.getFontManager().loadFonts(mFont, mAllowFont);
	}

	
	public Scene onLoadScene() {
		// TODO Auto-generated method stub
		mScene = new Scene(5);
		
		// load trackmaker
		loadTrackMaker();
		
		//
		setLayer_0();
		//setLayer_1();
		setLayer_2();
		setLayer_3();
		setLayer_4();
		playSound(Global.BACK_SOUND);
		
		initGame();
		
		fanHandle = new TimerHandler(1 / 60.0f, true, new ITimerCallback(){
			public void onTimePassed(final TimerHandler pTimerHandler) {
				startPlay();
			}
		});
		handle = new TimerHandler(1 / 30.0f, true, new ITimerCallback(){
			public void onTimePassed(final TimerHandler pTimerHandler) {
				movePaper();
			}
		});
		mScene.registerUpdateHandler(fanHandle);
		mScene.getLayer(0).registerTouchArea(mMenuSprite);
		mScene.getLayer(0).registerTouchArea(mMiddleBackgroundSprite);
		mScene.getLayer(3).registerTouchArea(mPaperSprite);

		mScene.setOnAreaTouchListener(new IOnAreaTouchListener(){
			boolean paper_click = false;
			
			public boolean onAreaTouched(TouchEvent pSceneTouchEvent,
					ITouchArea pTouchArea, float pTouchAreaLocalX,
					float pTouchAreaLocalY) {
				// TODO Auto-generated method stub
				if( !paper_click )
				{
					if(pTouchArea.equals(mMenuSprite))
					{
						stopSound(Global.BACK_SOUND);
						MiddleScene.this.finish();
					}
					if( mPaperInitRect.contains(pSceneTouchEvent.getX(), pSceneTouchEvent.getY()) )
						paper_click = true;
				}
				if(pSceneTouchEvent.getAction() == TouchEvent.ACTION_DOWN)
				{
				}
				else if( pSceneTouchEvent.getAction() == TouchEvent.ACTION_UP )
				{
					if( paper_click )
					{
						// get paper position from each frame
						if( !calcAlpha( pSceneTouchEvent.getX(), pSceneTouchEvent.getY() ) )
						{
							paper_click = false;
							return false;
						}		
						if (mTrackMaker.setThrowAngle(mAlpha) == 0)
						{
							paper_click = false;
							return false;
						}
						
						float rAlpha = mAlpha * 180 / 3.14f;
						mArrowSprite.setRotation(90 - rAlpha);
						
						mMove = true;
						paper_click = false;
						mScene.registerUpdateHandler(handle);
					}
				}
				return true;
			}
		});
		return mScene;
	}

	private void initGame()
	{
		randomDirectionAndSpeed();
		updateEntityDirAndSpeed( false );
		
		int nDirect;
		
		nDirect = mFanPosition == FAN_POSITION_LEFT ? 1 : -1;
			
		mTrackMaker.setWindSpeed(nDirect, m_rFan_A);
		
		mPaperSprite.setCurrentTileIndex(0);
		mPaperSprite.setSize(initWidth, initHeight);
		float x = (ptPaper.x-mPaperSprite.getWidth()/2);//*scaled_width;
		float y = (ptPaper.y-mPaperSprite.getHeight()/2);//*scaled_height;
		mPaperSprite.setPosition(x, y);

		mMove = false;
		mGoal = false;
		
		mScene.getLayer(4).removeEntity(mRecycleSprite);

		m_nFrameNum = 0;
		mPaperInitRect = new RectF(mPaperSprite.getX(), mPaperSprite.getY(), 
				mPaperSprite.getX()+mPaperSprite.getWidth(),//*scaled_width, 
				mPaperSprite.getY()+mPaperSprite.getHeight());//*scaled_height);
	}

	private void loadSound()
	{
		mSounds = new Sound[5];
		int nIdx = 0, nStep = 6;
		try{
			mMiddleBackMusic = MusicFactory.createMusicFromAsset(mEngine.getMusicManager(), this, "mfx/Level_Medium_Background.mp3");
			for(; nIdx < 5; nIdx ++)
			{
				//String filename = String.format("%d", nIdx + nStep);
				//mSounds[nIdx] = SoundFactory.createSoundFromAsset(mEngine.getSoundManager(), this, "mfx/" + filename + ".ogg");
				if (nIdx < 3)
					mSounds[nIdx] = SoundFactory.createSoundFromAsset(mEngine.getSoundManager(), this, "mfx/Level_Medium_BounceIn.mp3");
				else
					mSounds[nIdx] = SoundFactory.createSoundFromAsset(mEngine.getSoundManager(), this, "mfx/Level_Medium_BounceOut.mp3");
			}
		}catch(final IOException e)
		{
			
		}
	}
	
	private void setLayer_4() {
		mRecycleSprite = new Sprite( 0, 0, mRecycleTextureRegion );
		mRecycleSprite.setPosition(138*scaled_width, 223*scaled_height);
		mRecycleSprite.setSize(mRecycleSprite.getWidth()*scaled_width, mRecycleSprite.getHeight()*scaled_height);
		mScene.getLayer(4).addEntity(mRecycleSprite);
	}

	private void setLayer_3() {
		// TODO Auto-generated method stub
		mPaperSprite = new TiledSprite(0, 0, mPaperTextureRegion);
		initWidth = mPaperSprite.getWidth()*scaled_width;
		initHeight = mPaperSprite.getHeight()*scaled_height;
		float x = (ptPaper.x-initWidth/2);//*scaled_width;
		float y = (ptPaper.y-initHeight/2);//*scaled_height;
		mPaperSprite.setPosition(x, y);
		mScene.getLayer(3).addEntity(mPaperSprite);
	}

	private void setLayer_2() {
		// TODO Auto-generated method stub
		mArrowSprite = new Sprite(144*scaled_width, 384*scaled_height, mArrowTextureRegion);
		mArrowSprite.setSize(mArrowTextureRegion.getWidth() * scaled_width, mArrowTextureRegion.getHeight() * scaled_height);
		mScene.getLayer(2).addEntity(mArrowSprite);
		
		mWindArrowSprite[0] = new Sprite(0, 0, mWindArrowRegion[0]);
		mWindArrowSprite[0].setSize(mWindArrowRegion[0].getWidth() * scaled_width, mWindArrowRegion[0].getHeight() * scaled_height);
		mWindArrowSprite[0].setPosition((camera_width - mWindArrowRegion[0].getWidth() * scaled_width) / 2.0f , camera_height - 125 * scaled_height);

		mWindArrowSprite[1] = new Sprite(0, 0, mWindArrowRegion[1]);
		mWindArrowSprite[1].setSize(mWindArrowRegion[1].getWidth() * scaled_width, mWindArrowRegion[1].getHeight() * scaled_height);
		mWindArrowSprite[1].setPosition((camera_width - mWindArrowRegion[1].getWidth() * scaled_width) / 2.0f , camera_height - 125 * scaled_height);
	
		// loadFanScene();

		randomDirectionAndSpeed();
		
		String str = String.format("%.2f", m_rFan_A);
		mSpeedText = new ChangeableText(camera_width / 2.0f - 15 * scaled_width , camera_height - 145 * scaled_height, this.mAllowFont, str);
		updateEntityDirAndSpeed( true );
	}

	private void setLayer_1() {
		// TODO Auto-generated method stub
			loadFanScene();
	}

	private void setLayer_0()
	{
		mMiddleBackgroundSprite = new Sprite(0, 0, mMiddleBackgroundRegion);
		mMiddleBackgroundSprite.setSize(camera_width, camera_height);
		mScene.getLayer(0).addEntity(mMiddleBackgroundSprite);
		
		mMenuSprite = new Sprite(0, 0, mMenuRegion);
		mMenuSprite.setSize(mMenuRegion.getWidth() * scaled_width, mMenuRegion.getHeight() * scaled_width);
		mMenuSprite.setPosition(20 * scaled_width, 400 * scaled_height);
		mScene.getLayer(0).addEntity(mMenuSprite);
		
		ptScore = new PointF(40, 48);
		ptBest = new PointF(40, 67);
		initText(mScore, mBest);
	}

private void randomDirectionAndSpeed()
	{
		m_nFanIndex = 0;
		m_rFan_A = 0.0f;
		// direction
		randomDirection();
		
		// speed
		randomSpeed();
	}
	
	private void updateEntityDirAndSpeed( boolean first )
	{
		if( first )
		{
			if( mFanPosition == FAN_POSITION_LEFT )
			{
				//mScene.getLayer(1).addEntity(mFanLeftSprite[0]);
				mScene.getLayer(2).addEntity(mWindArrowSprite[0]);
			}
			else
			{
				//mScene.getLayer(1).addEntity(mFanRightSprite[0]);
				mScene.getLayer(2).addEntity(mWindArrowSprite[1]);
				//mWindArrowSprite[1].setRotation(180.0f);
			}
			mScene.getLayer(2).addEntity(mSpeedText);
		}
		else
		{
			if( mFanPosition == FAN_POSITION_LEFT )
			{
				//mScene.getLayer(1).setEntity(0, mFanLeftSprite[0]);
				mScene.getLayer(2).setEntity(1, mWindArrowSprite[0]);
				//mWindArrowSprite.setRotation(360.0f);
			}
			else
			{
				//mScene.getLayer(1).setEntity(0, mFanRightSprite[0]);
				mScene.getLayer(2).setEntity(1, mWindArrowSprite[1]);
				//mWindArrowSprite.setRotation(180.0f);
			}
			String str = String.format("%.2f", m_rFan_A);
			mSpeedText.setText(str);
		}
	}

	private void loadTrackMaker() {
		// TODO Auto-generated method stub
		mTrackMaker = new TrackMaker(scaled_width, scaled_height);
		mTrackMaker.setLevel(Global.LV_2);
		
		int x = mTrackMaker.m_levelInfo.nPaperInitX;
		int y = mTrackMaker.m_levelInfo.nPaperInitY;
		ptPaper = new PointF(x, y); // center position
	}

	
	public void onLoadComplete() {
		// TODO Auto-generated method stub
	}
	
	private void loadFanTexture()
	{
		String strRightFan = "gfx/fan_right_";
		String strLeftFan = "gfx/fan_left_";
		
		mFanRightTexture = new Texture[2];
		mFanRightTextureRegion = new TextureRegion[2];
		mFanLeftTexture = new Texture[2];
		mFanLeftTextureRegion = new TextureRegion[2];
	
		int nIdx = 0;
		for(; nIdx < 2; nIdx ++)
		{
			String str = String.format("%d", nIdx);
			mFanRightTexture[nIdx] = new Texture(512, 512, TextureOptions.DEFAULT);
			mFanLeftTexture[nIdx] = new Texture(512, 512, TextureOptions.DEFAULT);
			mFanRightTextureRegion[nIdx] = TextureRegionFactory.createFromAsset(mFanRightTexture[nIdx], this, strRightFan + str + ".png", 0, 0);
			mFanLeftTextureRegion[nIdx] = TextureRegionFactory.createFromAsset(mFanLeftTexture[nIdx], this, strLeftFan + str + ".png", 0, 0);
		}
	}
	
	private void playSound(int nType)
	{
		if(Global.SOUN_STATE == Global.SOUND_OFF)
			return;
		
		switch(nType)
		{
		case 0:
			mMiddleBackMusic.play();
			break;
		case Global.SOUND_STATE_IN:
			mSounds[0].play();
			break;
		case Global.SOUND_STATE_SIDE_IN:
			mSounds[1].play();
			break;
		case Global.SOUND_STATE_RING_IN:
			mSounds[2].play();
			break;
		case Global.SOUND_STATE_RIGN_OUT:
			mSounds[3].play();
			break;
		case Global.SOUND_STATE_OUT:
			mSounds[4].play();
			break;
		default:
			break;
		}
	}
	
	private void repeatSound()
	{
		if(Global.SOUN_STATE == Global.SOUND_OFF)
			return;
		
		if(!mMiddleBackMusic.isPlaying())
		{
			mMiddleBackMusic.play();
		}
	}

	private void stopSound(int nType)
	{
		if(Global.SOUN_STATE == Global.SOUND_OFF)
			return;
		switch(nType)
		{
		case 0:
			mMiddleBackMusic.stop();
			break;
		}
	}
	
	private void loadFanScene()
	{
		mFanRightSprite = new Sprite[2];
		mFanLeftSprite = new Sprite[2];
		
		PointF mRightPos = new PointF(219, 311);
		PointF mLeftPos = new PointF(1, 298);
		
		int nIdx = 0;
		for(; nIdx < 2; nIdx ++)
		{
			mFanRightSprite[nIdx] =  new Sprite(0, 0, mFanRightTextureRegion[nIdx]);
			mFanRightSprite[nIdx].setSize(mFanRightTextureRegion[nIdx].getWidth() * scaled_width,
					mFanRightTextureRegion[nIdx].getHeight() * scaled_height);
			mFanRightSprite[nIdx].setPosition(mRightPos.x * scaled_width, 
					mRightPos.y * scaled_height);
			
			mFanLeftSprite[nIdx] = new Sprite(0, 0, mFanLeftTextureRegion[nIdx]);
			mFanLeftSprite[nIdx].setSize(mFanLeftTextureRegion[nIdx].getWidth() * scaled_width,
					mFanLeftTextureRegion[nIdx].getHeight() * scaled_height);
			mFanLeftSprite[nIdx].setPosition(mLeftPos.x * scaled_width, 
					mLeftPos.y * scaled_height);
		}
	}

	private void startPlay()
	{
		repeatSound();
		//playFanAnimation();
	}
	
	private void movePaper()
	{
		if ( !mMove )
			return;
		m_nFrameNum ++;
		
		m_nCenterX = new int[1];
		m_nCenterY = new int[1];
		m_nBallIndex = new int[1];
		nState = new int[1];
		m_rScale = new float[1];
		
		if( m_nFrameNum == mTrackMaker.UP_FRAME_NUM )
		{
			mScene.getLayer(4).addEntity(mRecycleSprite);
			mScene.getLayer(3).removeEntity(mPaperSprite);
			mScene.getLayer(0).addEntity(mPaperSprite);
			mTopPaper = true;
		}
		mTrackMaker.getTrack(m_nFrameNum, m_nCenterX, m_nCenterY, m_rScale, m_nBallIndex, nState);
		
		if(Global.SOUN_STATE == Global.SOUND_ON && nState[0] != 0)
		{
			playSound(nState[0]);
		}
		
		if (mTrackMaker.getSuccess())
		{
			mGoal = true;
		}
		
		if (m_nFrameNum < mTrackMaker.getRealFrameNum())
		{
			calcBallInfo();			
		}
		
		int nScoreChange;
		
		if (m_nFrameNum == mTrackMaker.getRealFrameNum())
		{
			nScoreChange = mScore;
			mArrowSprite.setRotation(0);
			
			if (mGoal)
			{
				mScore ++;
				mBest = (mScore > mBest) ? mBest + 1 : mBest;			
				
				m_fSubmit = true;
			}
			else
			{
				mScore = 0;
			}
			
			if (m_fSubmit && (mScore != nScoreChange))
				updateText(mScore, mBest);
			
			mScene.unregisterUpdateHandler(handle);
			mScene.getLayer(0).removeEntity(mPaperSprite);
			mScene.getLayer(3).addEntity(mPaperSprite);
			mTopPaper = false;
			initGame();
			
			return;			
		}	
	}

	private void playFanAnimation()
	{
		if(mFanPosition == FAN_POSITION_LEFT)
		{
			if(m_nFanIndex == 0)
			{
				mScene.getLayer(1).setEntity(0, mFanLeftSprite[1]);
				m_nFanIndex = 1;
			}
			else
			{
				mScene.getLayer(1).setEntity(0, mFanLeftSprite[0]);
				m_nFanIndex = 0;
			}
		}
		else
		{
			if(m_nFanIndex == 0)
			{
				mScene.getLayer(1).setEntity(0, mFanRightSprite[1]);
				m_nFanIndex = 1;
			}
			else
			{
				mScene.getLayer(1).setEntity(0, mFanRightSprite[0]);
				m_nFanIndex = 0;
			}
		}
	}
	
	private void randomDirection()
	{
		int nDir = -1;

		nDir = (int)(Math.random() * 100) % 2;
		mFanPosition = (nDir == 0) ? FAN_POSITION_LEFT : FAN_POSITION_RIGHT;
	}
	
	private void randomSpeed()
	{
		int i = (int)(Math.random() * 100) % 6;
		int j = (int)(Math.random() * 1000) % 100;		
		float rTemp = j / 100.0f;
		m_rFan_A = i + rTemp;		
	}
	
	private void getScaledCoordinate()
	{
		DisplayMetrics displayMetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
		
		camera_width = displayMetrics.widthPixels;
		camera_height = displayMetrics.heightPixels;
		
		scaled_width = camera_width / Global.CAMERA_WIDTH;
		scaled_height = camera_height / Global.CAMERA_HEIGHT;
	}
	
	private void initText(int score, int best)
	{
		mScoreText = new ChangeableText(ptScore.x*scaled_width, ptScore.y*scaled_height, this.mFont, "Score  000");
		mBestText = new ChangeableText(ptBest.x*scaled_width, ptBest.y*scaled_height, this.mFont, "Best  000");
		mScoreText.setColor(1.0f, 1.0f, 1.0f);
		mBestText.setColor(1.0f, 1.0f, 1.0f);

		mScene.getLayer(0).addEntity(mScoreText);
		mScene.getLayer(0).addEntity(mBestText);

		mScoreText.setText("Score  " + mScore);
		mBestText.setText("Best  " + mBest);
	}
	
	private void updateText(int score, int best)
	{
		mScore = score; mBest = best;
		
		mScoreText.setText("Score  " + mScore);
		mBestText.setText("Best  " + mBest);
		if( mScore < mBest )
		{
			mScoreText.addShapeModifier(new ScaleModifier(0.7f, 3.0f, 1.0f));
			mScoreText.addShapeModifier(new MoveModifier(0.7f, 0, ptScore.x, camera_height/2, ptScore.y));
		}
		else
		{
			mScoreText.addShapeModifier(new ScaleModifier(0.7f, 3.0f, 1.0f));
			mScoreText.addShapeModifier(new MoveModifier(0.7f, 0, ptScore.x, camera_height/2, ptScore.y));
			mBestText.addShapeModifier(new ScaleModifier(0.7f, 3.0f, 1.0f));
			mBestText.addShapeModifier(new MoveModifier(0.7f, 0, ptBest.x, camera_height/2, ptBest.y));
		}
	}
	
	private boolean calcAlpha(float touchX, float touchY)
	{
		int x = mTrackMaker.m_levelInfo.nPaperInitX;
		int y = mTrackMaker.m_levelInfo.nPaperInitY;
		PointF pos = new PointF(x, y); // center position

		double rw = touchX - pos.x;
		double rh = touchY - pos.y;
		
		if (rh >= 0)
			return false;
		
		rh = -rh; 
		mAlpha = (float)Math.atan2(rh, rw);
		
		return true;
	}
	
	private void calcBallInfo()
	{
		float rWidth;
		
		mPaperSprite.setCurrentTileIndex(m_nBallIndex[0]);
		float x = m_nCenterX[0]-mPaperSprite.getWidth()/2;//*scaled_width;
		float y = m_nCenterY[0]-mPaperSprite.getHeight()/2;//*scaled_height;
		mPaperSprite.setPosition(x, y);
		rWidth = m_rInitPaperSize/8 * m_rScale[0];
		mPaperSprite.setSize(rWidth, rWidth);
		if( !mTopPaper )
			mScene.getLayer(3).setEntity(0, mPaperSprite);
		else
			mScene.getLayer(0).setEntity(4, mPaperSprite);
	}
}
