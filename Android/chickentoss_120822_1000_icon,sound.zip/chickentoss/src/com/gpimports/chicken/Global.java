package com.gpimports.chicken;

public class Global {
	// constant
	public static final float CAMERA_WIDTH = 320.0f;
	public static final float CAMERA_HEIGHT = 480.0f;
	public static final int 	MENU_BUTTON_COUNT = 4;
	
	//menu button constant
	public static final int EASY_BUTTON = 0;
	public static final int MIDDLE_BUTTON = 1;
	public static final int HARD_BUTTON = 2;
	public static final int AIRPORT_BUTTON = 3;
	public static final int BASEMENT_BUTTON = 4;
	public static final int RESTROOM_BUTTON = 5;
	public static final int PUB_BUTTON = 6;
	public static final int STREET_BUTTON = 7;
	
	//font size constant
	public static final int FONT_SIZE_SOUND	= 32;
	public static final int FONT_SIZE_ARROW = 20;
	
	//sound on/off flag
	public static int SOUN_STATE = 1;
	public final static int SOUND_ON = 1;
	public final static int SOUND_OFF = 0;
	
	//xml save /field name
	public static final String EASY_LEVEL = "EASY_LEVEL";
	public static final String MIDDLE_LEVEL = "MIDDLE_LEVEL";
	public static final String HARD_LEVEL = "HARD_LEVEL";
	public static final String AIRPORT_PLACE = "Airpot";
	public static final String BASEMENT_PLACE = "Basement";
	public static final String RESTROOM_PLACE = "Restroom";
	public static final String PUB_PLACE = "Pub";
	public static final String STREET_PLACE = "Street";
	
	//scores
	public static int gEasyScore = 0;
	public static int gMiddleScore = 0;
	public static int gHardScore = 0;
	public static int gAirportScore = 0;
	public static int gBasementScore = 0;
	public static int gRestroomScore = 0;
	public static int gPubScore = 0;
	public static int gStreetScore = 0;
	
	///
	public static boolean mIsStart = true;
	public static final int LV_1 = 0;
	public static final int LV_2 = 1;
	public static final int LV_3 = 2;
	public static final int LV_AIRPORT = 3;
	public static final int LV_BASEMENT = 4;
	public static final int LV_RESTROOM = 5;
	public static final int LV_PUB = 6;
	public static final int LV_STREET = 7;
	
	///sound index
	public static final int BACK_SOUND = 0;
	public static final int SOUND_STATE_IN = 1;
	public static final int SOUND_STATE_SIDE_IN	= 2;
	public static final int SOUND_STATE_RING_IN = 3;
	public static final int SOUND_STATE_RIGN_OUT = 4;
	public static final int SOUND_STATE_OUT = 5;
	
	// goal scores
	public static final int EASY_GOAL_SCORE = 10;
	public static final int MIDDLE_GOAL_SCORE = 20;
	public static final int HARD_GOAL_SCORE = 20;
	public static final int AIRPORT_GOAL_SCORE = 20;
	public static final int BASEMENT_GOAL_SCORE = 20;
	public static final int PUB_GOAL_SCORE = 20;
	public static final int RESTROOM_GOAL_SCORE = 20;
	public static final int STREET_GOAL_SCORE = 20;
	
	//flags
	public static boolean MIDDLE_LOCK = true;
	public static boolean HARD_LOCK = true;
	public static boolean AIRPORT_LOCK = true;
	public static boolean BASEMENT_LOCK = true;
	public static boolean PUB_LOCK = true;
	public static boolean RESTROOM_LOCK = true;
	public static boolean STREET_LOCK = true;
}
