//
//  PaperTossAppDelegate.h
//  PaperToss
//
//  Created by Developer on 2/19/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameDefine.h"

@class ChickenTossViewController;

@interface ChickenTossAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;

    ChickenTossViewController *viewController;
	
	UIImage* m_img1;
	UIImage* m_img2;
	UIImage* m_img3;
	UIImage* m_img4;
	UIImage* m_img5;
	UIImage* m_img6;
	UIImage* m_img7;
	UIImage* m_img8;
	UIImage* m_img9;
	UIImage* m_img10;
	UIImage* m_img11;
	UIImage* m_img12;
	UIImage* m_img13;
	UIImage* m_img14;
	UIImage* m_img15;
	UIImage* m_img16;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet ChickenTossViewController *viewController;

@property (nonatomic, retain) UIImage* m_img1;
@property (nonatomic, retain) UIImage* m_img2;
@property (nonatomic, retain) UIImage* m_img3;
@property (nonatomic, retain) UIImage* m_img4;
@property (nonatomic, retain) UIImage* m_img5;
@property (nonatomic, retain) UIImage* m_img6;
@property (nonatomic, retain) UIImage* m_img7;
@property (nonatomic, retain) UIImage* m_img8;
@property (nonatomic, retain) UIImage* m_img9;
@property (nonatomic, retain) UIImage* m_img10;
@property (nonatomic, retain) UIImage* m_img11;
@property (nonatomic, retain) UIImage* m_img12;
@property (nonatomic, retain) UIImage* m_img13;
@property (nonatomic, retain) UIImage* m_img14;
@property (nonatomic, retain) UIImage* m_img15;
@property (nonatomic, retain) UIImage* m_img16;

@end
