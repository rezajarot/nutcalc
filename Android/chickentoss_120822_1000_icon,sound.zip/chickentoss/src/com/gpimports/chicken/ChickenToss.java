package com.gpimports.chicken;

import org.anddev.andengine.engine.Engine;
import org.anddev.andengine.engine.camera.Camera;
import org.anddev.andengine.engine.options.EngineOptions;
import org.anddev.andengine.engine.options.EngineOptions.ScreenOrientation;
import org.anddev.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.scene.Scene.IOnAreaTouchListener;
import org.anddev.andengine.entity.scene.Scene.ITouchArea;
import org.anddev.andengine.entity.sprite.Sprite;
import org.anddev.andengine.input.touch.TouchEvent;
import org.anddev.andengine.opengl.texture.Texture;
import org.anddev.andengine.opengl.texture.TextureOptions;
import org.anddev.andengine.opengl.texture.region.TextureRegion;
import org.anddev.andengine.opengl.texture.region.TextureRegionFactory;

import android.content.Intent;
import android.util.DisplayMetrics;

public class ChickenToss extends BaseExample {
	/** Called when the activity is first created. */
	private int camera_width;
	private int camera_height;
	private float scaled_width = 0.0f;
	private float scaled_height = 0.0f;
	
	private Camera mCamera;
	
	private Scene mScene;
	private Texture mBackgroundTexture;
	private Texture mMenuButton[];
	private Texture mSoundTexture[];
	//private Texture mHighScoreTexture;
	
	private TextureRegion mBackgroundTextureRegion;
	private TextureRegion mMenuButtonRegion[];
	private TextureRegion mSoundRegion[];
	//private TextureRegion mHighScoreRegion;
	
	private Sprite mBackgroundSprite;
	private Sprite mMenuButtonSprite[];
	private Sprite mSoundSprite[];
	//private Sprite mHighScoreSprite;
	
	
	public Engine onLoadEngine() {
		// TODO Auto-generated method stub
		getScaledCoordinate();
		this.mCamera = new Camera(0, 0, camera_width, camera_height);
		return new Engine(new EngineOptions(true, ScreenOrientation.PORTRAIT, new RatioResolutionPolicy(camera_width, camera_height), this.mCamera));
	}

	
	public void onLoadResources() {
		// TODO Auto-generated method stub		
		mBackgroundTexture = new Texture( 1024, 1024, TextureOptions.DEFAULT );
		mBackgroundTextureRegion = TextureRegionFactory.createFromAsset(mBackgroundTexture, this, "gfx/background_menu.png", 0, 0);
		
		//mHighScoreTexture = new Texture( 256, 256, TextureOptions.DEFAULT );
		//mHighScoreRegion = TextureRegionFactory.createFromAsset(mHighScoreTexture, this, "gfx/score.png", 0, 0);
		
		mMenuButton = new Texture[Global.MENU_BUTTON_COUNT];
		mMenuButtonRegion = new TextureRegion[Global.MENU_BUTTON_COUNT];
		
		mSoundTexture = new Texture[2];
		mSoundTexture[0] = new Texture(256, 256, TextureOptions.DEFAULT);
		mSoundTexture[1] = new Texture(256, 256, TextureOptions.DEFAULT);
		
		mSoundRegion = new TextureRegion[2];
		mSoundRegion[0] = TextureRegionFactory.createFromAsset(mSoundTexture[0], this, "gfx/sound_off.png", 0, 0);
		mSoundRegion[1] = TextureRegionFactory.createFromAsset(mSoundTexture[1], this, "gfx/sound_on.png", 0, 0);
		
		int nIdx = 0;
		String[] str = new String[] {"easy", "medium", "hard", "quit"};
		for(; nIdx < Global.MENU_BUTTON_COUNT; nIdx ++)
		{
			//String str = String.format("%d", nIdx);
			mMenuButton[nIdx] = new Texture(1024, 1024, TextureOptions.DEFAULT);
			mMenuButtonRegion[nIdx] = TextureRegionFactory.createFromAsset(mMenuButton[nIdx], this, "gfx/menu_" + str[nIdx] + ".png", 0, 0);
			mEngine.getTextureManager().loadTexture(mMenuButton[nIdx]);
		}
		
		mEngine.getTextureManager().loadTextures(mBackgroundTexture, mSoundTexture[0], mSoundTexture[1]/*, mHighScoreTexture*/);
	}

	
	public Scene onLoadScene() {
		// TODO Auto-generated method stub
		mScene = new Scene(2);
		mBackgroundSprite = new Sprite(0, 0, mBackgroundTextureRegion);
		mBackgroundSprite.setSize(camera_width, camera_height);
		
		mMenuButtonSprite = new Sprite[Global.MENU_BUTTON_COUNT];
		//mHighScoreSprite = new Sprite(0, 0, mHighScoreRegion);
		//mHighScoreSprite.setSize(mHighScoreRegion.getWidth() * scaled_width, mHighScoreRegion.getHeight() * scaled_height);
		//mHighScoreSprite.setPosition(camera_width - (mHighScoreRegion.getWidth() + 20) * scaled_width, 100 * scaled_height);
		//mScene.getLayer(1).addEntity(mHighScoreSprite);
		//mScene.getLayer(1).registerTouchArea(mHighScoreSprite);
		
		loadSoundImage();
		loadMenuButton();
		
		mScene.getLayer(0).addEntity(mBackgroundSprite);
		
		mScene.setOnAreaTouchListener(new IOnAreaTouchListener(){
			
			public boolean onAreaTouched(TouchEvent pSceneTouchEvent,
					ITouchArea pTouchArea, float pTouchAreaLocalX,
					float pTouchAreaLocalY) {
				// TODO Auto-generated method stub
				Intent intent;
				if(pSceneTouchEvent.getAction() == TouchEvent.ACTION_UP)
				{
					if(pTouchArea.equals(mMenuButtonSprite[Global.EASY_BUTTON]))
					{
						intent = new Intent(ChickenToss.this, EasyScene.class);
						ChickenToss.this.startActivity(intent);
					}
					if(pTouchArea.equals(mMenuButtonSprite[Global.MIDDLE_BUTTON]))
					{
						intent = new Intent(ChickenToss.this, MiddleScene.class);
						ChickenToss.this.startActivity(intent);
					}
					if(pTouchArea.equals(mMenuButtonSprite[Global.HARD_BUTTON]))
					{
						intent = new Intent(ChickenToss.this, HardScene.class);
						ChickenToss.this.startActivity(intent);
					}
					if(pTouchArea.equals(mMenuButtonSprite[Global.AIRPORT_BUTTON]))
					{
						finish();
						System.exit(0);
						//intent = new Intent(PaperToss.this, AirportScene.class);
						//PaperToss.this.startActivity(intent);
					}
					/*if(pTouchArea.equals(mMenuButtonSprite[GlobalPaperToss.BASEMENT_BUTTON]))
					{
						intent = new Intent(PaperToss.this, BasementScene.class);
						PaperToss.this.startActivity(intent);
					}
					if(pTouchArea.equals(mMenuButtonSprite[GlobalPaperToss.RESTROOM_BUTTON]))
					{
						intent = new Intent(PaperToss.this, RestroomScene.class);
						PaperToss.this.startActivity(intent);
					}
					if(pTouchArea.equals(mMenuButtonSprite[GlobalPaperToss.PUB_BUTTON]))
					{
						intent = new Intent(PaperToss.this, PubScene.class);
						PaperToss.this.startActivity(intent);
					}
					if(pTouchArea.equals(mMenuButtonSprite[GlobalPaperToss.STREET_BUTTON]))
					{
						intent = new Intent(PaperToss.this, StreetScene.class);
						PaperToss.this.startActivity(intent);
					}*/
					if(mSoundSprite[Global.SOUN_STATE].contains(pSceneTouchEvent.getX(), pSceneTouchEvent.getY()))
					{
						if(Global.SOUN_STATE == 0)
						{
							mScene.getLayer(1).removeEntity(mSoundSprite[0]);
							mScene.getLayer(1).addEntity(mSoundSprite[1]);
							Global.SOUN_STATE = 1;
						}
						else if(Global.SOUN_STATE == 1)
						{
							mScene.getLayer(1).removeEntity(mSoundSprite[1]);
							mScene.getLayer(1).addEntity(mSoundSprite[0]);
							Global.SOUN_STATE = 0;
						}
					}
					/*if(pTouchArea.equals(mHighScoreSprite))
					{
						intent = new Intent(PaperToss.this, HighScoreScene.class);
						PaperToss.this.startActivity(intent);
					}*/
				}
				return true;
			}
		});
		return mScene;
	}

	
	public void onLoadComplete() {
		// TODO Auto-generated method stub
		
	}
	
	private void loadMenuButton()
	{
		float rWidth = mMenuButtonRegion[0].getWidth();
		float rHeight = mMenuButtonRegion[0].getHeight();
		
		int nIdx = 0;
		for(; nIdx < Global.MENU_BUTTON_COUNT; nIdx ++)
		{
			mMenuButtonSprite[nIdx] = new Sprite(0, 0, mMenuButtonRegion[nIdx]);
			mMenuButtonSprite[nIdx].setSize(rWidth / 2 * scaled_width, rHeight / 2 * scaled_height);
		}
		
		mMenuButtonSprite[0].setPosition(177 / 2 * scaled_width, 522 / 2 * scaled_height);
		mMenuButtonSprite[1].setPosition(194 / 2 * scaled_width, 610 / 2 * scaled_height);
		mMenuButtonSprite[2].setPosition(182 / 2 * scaled_width, 703 / 2 * scaled_height);
		mMenuButtonSprite[3].setPosition(196 / 2 * scaled_width, 787 / 2 * scaled_height);
		//mMenuButtonSprite[4].setPosition(80 * scaled_width, 380 * scaled_height);
		//mMenuButtonSprite[5].setPosition(170 * scaled_width, 405 * scaled_height);
		//mMenuButtonSprite[6].setPosition(60 * scaled_width, 423 * scaled_height);
		//mMenuButtonSprite[7].setPosition(189 * scaled_width, 440 * scaled_height);
		
		for(nIdx = 0; nIdx < Global.MENU_BUTTON_COUNT; nIdx ++)
		{
			mScene.getLayer(1).addEntity(mMenuButtonSprite[nIdx]);
			mScene.getLayer(1).registerTouchArea(mMenuButtonSprite[nIdx]);
		}
	}
	
	private void loadSoundImage()
	{
		mSoundSprite = new Sprite[2];
		mSoundSprite[0] = new Sprite(0, 0, mSoundRegion[0]);
		mSoundSprite[1] = new Sprite(0, 0, mSoundRegion[1]);
		mSoundSprite[0].setSize(mSoundRegion[0].getWidth() * scaled_width, mSoundRegion[0].getHeight() * scaled_height);
		mSoundSprite[1].setSize(mSoundRegion[1].getWidth() * scaled_width, mSoundRegion[1].getHeight() * scaled_height);
		mSoundSprite[0].setPosition(camera_width - mSoundSprite[0].getWidth() - 50, 80 * scaled_height);
		mSoundSprite[1].setPosition(camera_width - mSoundSprite[0].getWidth() - 50, 80 * scaled_height);
		mScene.getLayer(1).addEntity(mSoundSprite[Global.SOUN_STATE]);
		mScene.getLayer(1).registerTouchArea(mSoundSprite[0]);
		mScene.getLayer(1).registerTouchArea(mSoundSprite[1]);
	}
	
	private void getScaledCoordinate()
	{
		DisplayMetrics displayMetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
		
		camera_width = displayMetrics.widthPixels;
		camera_height = displayMetrics.heightPixels;
		
		scaled_width = camera_width / Global.CAMERA_WIDTH;
		scaled_height = camera_height / Global.CAMERA_HEIGHT;
	}
}