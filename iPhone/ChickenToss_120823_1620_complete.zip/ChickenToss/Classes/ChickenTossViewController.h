//
//  PaperTossViewController.h
//  PaperToss
//
//  Created by Developer on 2/19/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EasyViewController.h"
#import "MediumViewController.h"
#import "HardViewController.h"
//#import "AirportViewController.h"
//#import "BasementViewController.h"
//#import "RestroomViewController.h"
//#import "PubViewController.h"
//#import "StreetViewController.h"
//#import "SBoardViewController.h"
//#import "MoreGameViewController.h"
#import "TrackMaker.h"

#import <AudioToolbox/AudioToolbox.h>

@interface ChickenTossViewController : UIViewController <UINavigationControllerDelegate, EasyViewControllerDelegate, MediumViewControllerDelegate, HardViewControllerDelegate/*, 
											AirportViewControllerDelegate, BasementViewControllerDelegate, RestroomViewControllerDelegate, PubViewControllerDelegate, 
											StreetViewControllerDelegate, SBoardViewControllerDelegate, MoreGameViewControllerDelegate*/> 
{
	IBOutlet EasyViewController *easyController;
	IBOutlet MediumViewController *mediumController;	
	IBOutlet HardViewController *hardController;	
	//IBOutlet AirportViewController *airportController;	
	//IBOutlet BasementViewController *basementController;	
	//IBOutlet RestroomViewController *restroomController;
	//IBOutlet PubViewController *pubController;
	//IBOutlet StreetViewController *streetController;	
	//IBOutlet SBoardViewController* sboardViewController;
	//IBOutlet MoreGameViewController* moregameViewController;
	
	IBOutlet UIButton *btEasy;
	IBOutlet UIButton *btMedium;	
	IBOutlet UIButton *btHard;	
	IBOutlet UIButton *btAirport;
	IBOutlet UIButton *btBasement;
	IBOutlet UIButton *btRestroom;
	IBOutlet UIButton *btPub;
	IBOutlet UIButton *btStreet;
	IBOutlet UIButton *btRemoveAds;	
	IBOutlet UIButton *btSelSBoard;
	IBOutlet UIButton *btSound;
	
	SystemSoundID m_BouncelnSound;
	SystemSoundID m_CrumpleSound;
	SystemSoundID m_InSound;
	SystemSoundID m_OutSound;
	SystemSoundID m_RimInSound;
	SystemSoundID m_RimOutSound;
	
	BOOL m_fSound;	
	
	int easyScore;
	int mediumScore;
	int hardScore;
	int airportScore;
	int basementScore;
	int restroomScore;
	int pubScore;
	int streetScore;
	
	TrackMaker* m_TrackMaker;
}

-(IBAction)onEasy:(id)sender;
-(IBAction)onMedium:(id)sender;
-(IBAction)onHard:(id)sender;
-(IBAction)onQuit:(id)sender;
/*-(IBAction)onAirport:(id)sender;
-(IBAction)onBasement:(id)sender;
-(IBAction)onRestroom:(id)sender;
-(IBAction)onPub:(id)sender;
-(IBAction)onStreet:(id)sender;
-(IBAction)onRemoveAds:(id)sender;
-(IBAction)onSelSBoard:(id)sender;
-(IBAction)onMoreGames:(id)sender;*/
-(IBAction)onSoundOnOff:(id)sender;

-(void)playBounceInSound;
-(void)playCrumpleSound;
-(void)playInSound;
-(void)playOutSound;
-(void)playRimInSound;
-(void)playRimOutSound;

@end

